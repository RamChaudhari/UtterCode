# file = open('sample3.py' , 'w')
# file.write("ram = 10")
# file.write("\nprint(ram)")
# file.close

exec(open('sample3.py').read())
