file = open("delete.txt",'a+')

num = file.readline()